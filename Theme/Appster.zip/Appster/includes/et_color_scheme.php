<style type="text/css">
p a, p a:visited, .section-title h1 span, .menu li.active a, .menu li.active a:hover, 
.showcase-content h1 span, .team-member-socials li:hover i, .social-network-links i:hover, 
.check-list i, .button.color:hover, input[type="submit"]:hover, input[type="reset"]:hover, input[type="button"]:hover,
.menu a:hover, .widget a, h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, a, .entry-title, .entry-title > a,
.page-template-default h1, .page-template-default h2, .page-template-default h3, .menu a:hover, .page-template-default h4, .et-loading-icon, .page-template-default h5, .page-template-default h6, .mobile-menu.colored

{color: <?php echo ot_get_option('et_color_scheme'); ?>;}

.logo, .logo-area, .feature-icon-box:hover i, .zoomer-bg, .zoomer-bg .overlay, .title-bullet span, 
.screenshot .overlay, .lightbox-close i, .team-member-bullet i, .counter h4, .testimonials .overlay, 
.twitter-feed .overlay, .twitter-feed-icon, .price-table-header span, .call-to-action .overlay, 
.feature-selector-buttons li.active .selector-body, .button.color, .portfolio .filter a.selected,
.portfolio-item-bullet i, input[type="submit"], input[type="reset"], .et-loading-progress span, input[type="button"], .client-link:hover

{background: <?php echo ot_get_option('et_color_scheme'); ?>;}

.button.color, .button.color:hover, .feature-selector-buttons li.active .selector-triangle, input[type="submit"]:hover, input[type="reset"]:hover, input[type="button"]:hover, .sticky, blockquote, .et-loading-frame

{border-color: <?php echo ot_get_option('et_color_scheme'); ?>;}
</style>